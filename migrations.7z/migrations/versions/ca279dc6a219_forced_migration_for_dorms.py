"""forced migration for dorms

Revision ID: ca279dc6a219
Revises: 2de6de1d8403
Create Date: 2023-11-22 10:01:11.858281

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = 'ca279dc6a219'
down_revision = '2de6de1d8403'
branch_labels = None
depends_on = None


def upgrade():
    pass


def downgrade():
    pass
